tmp0=1
tmp1=10
tmp2=tmp1
tmp3=tmp1
tmp4=tmp0
tmp5=tmp1
tmp1+3+input()
tmp6=tmp0
tmp7=tmp1
print tmp3
print tmp2
print tmp6
print tmp7
