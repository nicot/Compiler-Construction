x =-input()+-input()+1+-10
z = x + x + -x
print z 
