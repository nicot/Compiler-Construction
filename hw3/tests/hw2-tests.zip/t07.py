x=4+-5
y=93+-x
print -x+-y
