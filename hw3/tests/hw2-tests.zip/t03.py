tmp1 = input()
tmp1 = 1
tmp0 = 2 + tmp1
print tmp0
