x = 100 + 2
print x
