x = {1: 2, 2: 5}
y = x[1] + 1
print y + x[2]
