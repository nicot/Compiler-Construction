x = input() and True
y = input() or False
