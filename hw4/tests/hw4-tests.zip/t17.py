x = [1,5,10]
y = [x,x[2],x[0]]
print y
