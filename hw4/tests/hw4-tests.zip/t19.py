y = True or False
print y
