-input()+input()+4+input()
print input()
