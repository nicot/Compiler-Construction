print input() if input() else [input()]
