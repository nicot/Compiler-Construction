a = input()
b = a + 9
c = 39
d = input() + c + -b
e = 10
f = d + a
g = e + c
h = f + g
i = c + a
j = h + -i + e + d
k = 10 + j + 30 + b
l = a + k
m = 1 + a 
n = m + l + d + f + c + -l + j + l + h
print n
o = a + n
p = g + m 
q = a + b + c + d + e + f + g + h + i + j + k + l + m + n + o + p
