x = [input(), 3, input()]
y = x + x
z = {1: x, 2: y}
print z
