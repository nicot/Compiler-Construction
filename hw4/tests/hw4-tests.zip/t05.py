x=5
y=78
z=11
w=x+y+z+input()
x=input()+w
print x
